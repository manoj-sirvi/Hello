import './registration.css' 
import React, { useState } from 'react';
import axios from "axios";
import Home from '../home/home.js'

function Registration(){
  const [isChecked, setIsChecked] = useState(true);
  const [name,setName]=useState("");
  const [email,setEmail]=useState("");
  const [password,setpassword]=useState("");
  const handleCheckboxChange = (e) => {
    console.log(isChecked);
    setIsChecked(!isChecked);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const user={
        "name":name,
        "email":email,
        "password":password
      }
      console.log(user);
      
      axios.post("http://localhost:1337/user/api/registration",user).then(res=>{
         console.log(res.data);
      }).catch(error=>{
        console.log(error);
      })
      
    // console.log("hiiii");
    // Perform form submission logic here
  };

  
    return(
    
      <>
      <Home/>
     <form onSubmit={handleSubmit}>
    <div className="container">
      {/* <label htmlFor="uname"><b>Username</b></label> */}
      <input type="text" placeholder="Enter Username" value={name} onChange={(e)=>setName(e.target.value)} required/>

      {/* <label htmlFor="uname"><b>Email</b></label><br/> */}
      <input value={email} type="text" placeholder="Enter Email" onChange={(e)=>setEmail(e.target.value)} required/>
      <br/>
      {/* <label value={password} htmlFor="psw"><b>Password</b></label> */}
      <input value={password} type="password" placeholder="Enter Password" onChange={(e)=>setpassword(e.target.value)}  required/>
      <button type="submit">Register</button>
      <label>
        <input type="checkbox" defaultChecked={isChecked} name="remember" onChange={handleCheckboxChange}/> Remember me
      </label>
    </div>

    <div className="container" style={{backgroundColor: "#f1f1f1"}}>
    {/* <button type="button" className="cancelbtn">Cancel</button> */}
    <span className="psw">Forgot <a href="#">password?</a></span>
        </div>
      

    </form>

    </>


    );
}


export default Registration;
