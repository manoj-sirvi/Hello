import './login.css' 
import React, { useState } from 'react';
import axios from "axios";
import Home from '../home/home.js'
function Login(){
  const [isChecked, setIsChecked] = useState(true);
  const [name,setName]=useState("");
  const [email,setEmail]=useState("");
  const [password,setpassword]=useState("");
  const handleCheckboxChange = (e) => {
    console.log(isChecked);
    setIsChecked(!isChecked);
  };

  console.log(name)
  async function Login(event){
      //  pri
      event.preventDefault();
      const user={
        "name":name,
        "email":email,
        "password":password
      }
      
      await axios.post("http://localhost:1337/user/api/login",user).then(res=>{
         console.log(res.data);
         if(res.data.user){
          localStorage.setItem('token',res.data.user);
          alert('login successfully')
          window.location.href='./dashboard'
        }
        else{
          alert('Please check your username and password')
        }
      }).catch(error=>{
        console.log(error);
      })

      // const data=await response.json()

      

      
  }
    return(
      <>
      <Home/>
     <form onSubmit={Login}>
    <div className="container">
      {/* <label htmlFor="uname"><b>Username</b></label> */}
      <input type="text" placeholder="Enter Username" value={name} onChange={(e)=>setName(e.target.value)} required/>

      {/* <label htmlFor="uname"><b>Email</b></label><br/> */}
      <input value={email} type="text" placeholder="Enter Email" onChange={(e)=>setEmail(e.target.value)} required/>
      <br/>
      {/* <label value={password} htmlFor="psw"><b>Password</b></label> */}
      <input value={password} type="password" placeholder="Enter Password" onChange={(e)=>setpassword(e.target.value)}  required/>
      <button type="submit">Login</button>
      <label>
        <input type="checkbox" defaultChecked={isChecked} name="remember" onChange={handleCheckboxChange}/> Remember me
      </label>
    </div>

    <div className="container" style={{backgroundColor: "#f1f1f1"}}>
    {/* <button type="button" className="cancelbtn">Cancel</button> */}
    <span className="psw">Forgot <a href="#">password?</a></span>
        </div>

    </form>




    </>


    );
}


export default Login;

// 1 1 5 5 9 9
// 0 3 1 4 2 5
// 0 1 2 3 4 5
// 0 2 0
// 1 3 1
// 2 4 1
// 3 5 2
// 0 4 0
// 1 5 1