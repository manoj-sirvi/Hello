import React from "react";
import axios from "axios";
import { useState,useEffect } from "react";
import { useSearchParams,useLocation  } from 'react-router-dom';
import PlotComponent from "./placecomponent";
import Chart from 'chart.js/auto';

export default function Handling(){
   const [view,setView]=useState([])
   const [queries,setQuries]=useState([])
//    const navigate = useNavigate();
const [chartInstances, setChartInstances] = useState([]);
    const location = useLocation();
    const [searchParams] = useSearchParams(location.search);
   const projectId = searchParams.get('projectId');
   useEffect(()=>{
     async function Getqeuries(){
        await axios.get("http://localhost:1337/userproject/api/plot",{
            headers:{
                'x-access-token':localStorage.getItem('token'),
                // information:{
                 'projectid':projectId
                // }
            }
        }).then((res)=>{
            console.log(res.data.queries)
            setQuries(res.data.queries)
        }).catch((err)=>{
            console.log("jsfgwjef wkfwkef")
        })
     }
     Getqeuries()
   },[projectId])

   useEffect(()=>{
    async function GetView(){
        try {
            console.log("testing")
            const responses = await Promise.all(
              queries.map(async (query) => {
                return axios.post("http://localhost:1337/userproject/api/plotting", {
                  headers: {
                    'x-access-token': localStorage.getItem('token'),
                  },
                  body: {
                    projectid: projectId,
                    query: query,
                  },
                });
              })
            );
      
            const data = responses.map((response) => response.data.data);
            console.log("datat",data);

            setView(data);
          } catch (error) {
            console.log("Error occurred while fetching data");
          }
        }
    GetView()
  },[projectId,queries])

   async function ShareGraph(e,dataEntry,currentValue){
    e.preventDefault();
    await axios.post('http://localhost:1337/sharing/api/shared',{
         headers:{
          'x-access-token':localStorage.getItem('token')
         },
         body:{
           userid2:currentValue,
           projectId:projectId,
           data:dataEntry
         }
    }).then((res)=>{
       alert("successfully shared")

    }).catch((res)=>{
         alert("Error while sharing")
    })
  }

  useEffect(() => {
     const createPlots = () => {
      view.forEach((dataEntry, index) => {
        const plotElement = document.getElementById(`plot-${index}`);
        const data = dataEntry.content;
        console.log("hello mr manoj")
        // const xData = data.map(obj => obj.x);
        // const yData = data.map(obj => obj.y);
        const xData = dataEntry.map((dataPoint) => dataPoint.data.time);
        const yData = dataEntry.map((dataPoint) => dataPoint.data.value);
        console.log(xData,yData)
        // Check if a chart already exists on the canvas element
        if (plotElement.chart) {
          plotElement.chart.destroy();
        }
  
        const chart = new Chart(plotElement, {
            type: 'line',
                    data: {
                      labels: xData,
                      datasets: [{
                        label: 'Y Values',
                        data: yData,
                        borderColor: 'blue',
                        fill: false
                      }]
                    },
                    options: {
                      responsive: true,
                      scales: {
                        x: {
                          type: 'linear',
                          position: 'bottom',
                        //   max: 40, // Set the maximum value of the x-axis
                        //   min: 0,  // Set the minimum value of the x-axis
                        },
                      }
                    }
        });
  
        // Store the chart instance as a property of the canvas element
        plotElement.chart = chart;
      });
    };
  
    createPlots();
//   }, [plotData]);
  }, [view]);
  
   return (<>
   {
    <div>
        <ul>
                {view.map((dataEntry, index) => (
                    <PlotComponent
                      key={index}
                      dataEntry={dataEntry}
                      index={index}
                      ShareGraph={ShareGraph}
                    />
                  ))}
        </ul>
    </div>
   }
    
    
    </>)
}