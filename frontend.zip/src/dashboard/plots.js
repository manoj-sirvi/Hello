import React, { useState, useEffect } from 'react';
import Chart from 'chart.js/auto';
import axios from 'axios';
import { useSearchParams,useLocation  } from 'react-router-dom';
import PlotComponent from './placecomponent';
import { useNavigate } from 'react-router-dom';
import ProjectPage from './projects';
function PlotPage() {
  const [plotData, setPlotData] = useState([]);
  const location = useLocation();
  const [searchParams] = useSearchParams(location.search);
  const projectId = searchParams.get('projectId');
  // const [currentvalue,setCurrentalue] = useState('');

  // const handleInputChange=(e)=>{
  //    setCurrentalue(e.target.value)
  // }

  useEffect(() => {
    const clearLocalStorage = () => {
      if (!isPageReloading()) {
        localStorage.removeItem('third-email');
      }
    };
  
    const handlePopstate = () => {
      clearLocalStorage();
    };
  
    const handleBeforeUnload = () => {
      if (!isPageReloading()) {
        clearLocalStorage();
      }
    };
  
    const isPageReloading = () => {
      return performance.navigation.type === 1;
    };
  
    window.addEventListener('popstate', handlePopstate);
    window.addEventListener('beforeunload', handleBeforeUnload);
  
    return () => {
      window.removeEventListener('popstate', handlePopstate);
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, []);
  

  // useEffect(() => {
  //   // Fetch data from the backend API
  //   const fetchData = async () => {
  //     try {
  //       const email=localStorage.getItem('third-email')
  //       console.log(email)
  //       const response = await axios.get(`http://localhost:1337/userproject/api/username/data/${email}`,{
  //           headers:{
  //               'x-access-token':localStorage.getItem('token'),
  //               'Content-Type':'Application/json',
  //               'id':projectId,

  //           }
  //   }); // Replace with your API endpoint
  //       console.log(typeof response.data)
  //       const data = response.data;

  //       // Update the component state with the fetched data
  //       setPlotData(data);
  //     } catch (error) {
  //       console.error('Error fetching data:', error);
  //     }
  //   };

  //   fetchData();
  // }, []);

  // useEffect(() => {
  //   const createPlots = () => {
  //     plotData.forEach((dataEntry, index) => {
  //       const plotElement = document.getElementById(`plot-${index}`);
  //       const data = dataEntry.content;
  //       console.log("hello mr manoj")
  //       const xData = data.map(obj => obj.x);
  //       const yData = data.map(obj => obj.y);
  //       console.log(xData,yData)
  //       // Check if a chart already exists on the canvas element
  //       if (plotElement.chart) {
  //         plotElement.chart.destroy();
  //       }
  
  //       const chart = new Chart(plotElement, {
  //         type: 'line',
  //         data: {
  //           labels: xData,
  //           datasets: [{
  //             label: 'Y Values',
  //             data: yData,
  //             borderColor: 'blue',
  //             fill: false
  //           }]
  //         },
  //         options: {
  //           responsive: true,
  //           scales: {
  //             x: {
  //               type: 'linear',
  //               position: 'bottom',
  //               max: 40, // Set the maximum value of the x-axis
  //               min: 0,  // Set the minimum value of the x-axis
  //             },
  //           }
  //         }
  //       });
  
  //       // Store the chart instance as a property of the canvas element
  //       plotElement.chart = chart;
  //     });
  //   };
  
  //   createPlots();
  // }, [plotData]);
  
  async function ShareGraph(e,dataEntry,currentValue){
    e.preventDefault();
    await axios.post('http://localhost:1337/sharing/api/shared',{
         headers:{
          'x-access-token':localStorage.getItem('token')
         },
         body:{
           userid2:currentValue,
           projectId:projectId,
           data:dataEntry
         }
    }).then((res)=>{
       alert("successfully shared")

    }).catch((res)=>{
         alert("Error while sharing")
    })
  }
  
  return (
    <div>
    <h1>Plot Page</h1>
    {plotData.map((dataEntry, index) => (
      <PlotComponent
        key={index}
        dataEntry={dataEntry}
        index={index}
        ShareGraph={ShareGraph}
      />
    ))}
  </div>
  );  
}  

export default PlotPage;
