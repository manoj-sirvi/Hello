// import axios from "axios"
import React, { useEffect, useState } from "react"
import Chart from 'chart.js/auto';
import axios from 'axios';
export default function Shared(){
//    const [shared, setShared]=useState([])
   const [plotData, setPlotData] = useState([]);

   useEffect(()=>{
     async function Get(){
        await axios.get("http://localhost:1337/sharing/api/getshareditems",{
              headers:{
                'x-access-token':localStorage.getItem('token')
              }
          
        }).then((res)=>{
            console.log("datatset")
            console.log(res.data)
            setPlotData(res.data)
        }).catch((res)=>{
            console.log("error")

        })
     }
     Get();
   },[])

   useEffect(() => {
    const createPlots = () => {
      plotData.forEach((dataEntry, index) => {
        const plotElement = document.getElementById(`plot-${index}`);
        console.log(dataEntry)
        const data = dataEntry.data;
        console.log("hello mr manoj")
        const xData = data.map(obj => obj.x);
        const yData = data.map(obj => obj.y);
        console.log("hello")
        console.log(xData,yData)
        // Check if a chart already exists on the canvas element
        if (plotElement.chart) {
          plotElement.chart.destroy();
        }
  
        const chart = new Chart(plotElement, {
          type: 'line',
          data: {
            labels: xData,
            datasets: [{
              label: 'Y Values',
              data: yData,
              borderColor: 'blue',
              fill: false
            }]
          },
          options: {
            responsive: true,
            scales: {
              x: {
                type: 'linear',
                position: 'bottom'
              }
            }
          }
        });
  
        // Store the chart instance as a property of the canvas element
        plotElement.chart = chart;
      });
    };
  
    createPlots();
  }, [plotData]);
   
    return(<>
    <>See the share items</>
    {
    plotData.map((dataEntry, index) => {
        // console.log(dataEntry)
        return (
        <div key={index}>
        <canvas id={`plot-${index}`} width={400} height={200}></canvas>
        </div>
        )
     })
    }

    </>)
}