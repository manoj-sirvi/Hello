import axios from 'axios';
import React, { useState,useEffect } from 'react';
// import { useHistory } from 'react-router';
import { useNavigate } from 'react-router-dom';
const ProjectPage = () => {
  const navigate = useNavigate();
  // const history = useHistory();
  const [showForm, setShowForm] = useState(false);
  const [projects, setProjects] = useState([]);
  const[projectname,setName]=useState("")
  const[description,setDescription]=useState("")
  useEffect(() => {
    fetchProjects();
  }, []);
  
  useEffect(() => {
    console.log("hiih",projects); // Check if the projects state is updated
  }, [projects]);
  
  const fetchProjects = async () => {
    try {
      const response = await axios.get('http://localhost:1337/project/api/projects', {
        headers: {
          'x-access-token': localStorage.getItem('token'),
          'Content-Type': 'application/json',
          // 'accesslevel':
        },
      });
      setProjects(response.data);
    } catch (error) {
      console.error('Error fetching projects:', error);
    }
  };
  async function handleSubmit(e){
    e.preventDefault();
      const project={
        name:projectname,
        description:description
      }
      console.log(project)
      await axios.post("http://localhost:1337/userproject/api/createproject",{
        headers:{
         'x-access-token': localStorage.getItem('token')
        }
    ,project}).then((res)=>{
        if(res.data.status==='ok'){
          alert("Project Create successfully")
          // createProject()
          // setProjects(res.data);
          setProjects([...projects, res.data.project]);
          setName("");
          setDescription("");
          console.log(description,projectname)
        }
        else{
            alert("Error in Creating Project")
        }
        console.log("success")
      }).catch((error)=>{
        console.log(error)
        // alert("Error in Creating Project")
      })
    }
      

  
     
  const handleClick = (projectId,accesslevel) => {
    // const projectId = 'your-project-id'; // Specify the project ID you want to send
    const url = `/projects?projectId=${projectId}&access=${accesslevel}`;
    // history.push(url);
    navigate(url);
  };
  

  const fetchProjectData = async (projectId,accesslevel) => {
    try {
      console.log(accesslevel)
      const response = await axios.get(`http://localhost:1337/userproject/api/projects/${projectId}`, {
        headers: {
          'x-access-token': localStorage.getItem('token'),
          'Content-Type': 'application/json',
          'accesslevel':accesslevel
        },
      });
      const projectData = response.data;
      // window.location.href='./projects/users'
      // Process the fetched project data as needed
      console.log(projectData);
    } catch (error) {
      console.error('Error fetching project data:', error);
    }
  };
  
  const handleCreateProject = () => {
    setShowForm(true);
  };
  function SharedItems(e){
    navigate('/projects/shared');
  }
  return (
   
    <div>
      <h1>Project Page</h1>
      {
         
      }
      {!showForm ? (
        <button onClick={handleCreateProject}>Create Project</button>
      ) : (
        <form onSubmit={handleSubmit}>
          {/* Your form inputs go here */}
          <input type="text" placeholder="Project name" onChange={(e)=>setName(e.target.value)} />
          <input type="text" placeholder="Project description" onChange={(e)=>setDescription(e.target.value)} />
          {/* ... other form inputs */}
          <button type="submit">Submit</button>
        </form>
      )}
      {/* {
      console.log(projects['0'])
      } */}
      <h2>Projects:</h2>
      { console.log(projects)}
      {/* <ul>
  {projects.map((project) => {
    // console.log("ello",project)
    // console.log(project.id)
    // console.log(project['0'],project.description); // Add console.log here
     return <li key={project.id} onClick={() => handleClick(project.id)}>{project.description}</li>;
  })}
</ul> */}
{projects.length > 0 && (
  <ul>
    {projects.map((project) => {
      return (
        <li key={project.id} onClick={() => handleClick(project.id,project.accesslevel)}>
          {project.description}{project.accesslevel}
        </li>
      );
    })}
  </ul>
)}
<h2>Shared Expeimentes</h2>
<div>
  <button onClick={(e)=>{SharedItems(e)}}>See Shared Items</button>
</div>
    </div>
    
  );
};

export default ProjectPage;
