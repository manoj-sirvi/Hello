import axios from 'axios';
import React, { useState,useEffect } from 'react';
import { json } from 'react-router-dom';
import { useSearchParams,useLocation  } from 'react-router-dom';

import { useNavigate } from 'react-router-dom';
export default function Project(){
    const navigate = useNavigate();
    const location = useLocation();
    const [searchParams] = useSearchParams(location.search);
    const projectId = searchParams.get('projectId');
    const accesslevel=searchParams.get('access')
    const [users,SetUsers]=useState([])
    const handleClick = (userId,username) => {
        // const projectId = 'your-project-id'; // Specify the project ID you want to send
        console.log("helllp",userId)
        const url = `/users?projectId=${projectId}&username=${username}`;
        localStorage.setItem('third-email',userId);
        // history.push(url);
        console.log(localStorage.getItem('third-email'))
        navigate(url);
      };
      const handlePlot=(userId,username)=>{
        const url = `/users/plots?projectId=${projectId}&username=${username}`;
        localStorage.setItem('third-email',userId);
        // history.push(url);
        console.log(localStorage.getItem('third-email'))
        navigate(url);

      }

    useEffect(()=>{
        const fetchProjectData = async (projectId) => {
            try {
              console.log(projectId)
               await axios.get(`http://localhost:1337/userproject/api/projects/${projectId}`, {
                headers: {
                  'x-access-token': localStorage.getItem('token'),
                  'Content-Type': 'application/json',
                  'accesslevel':accesslevel
                },
              }).then((res)=>{
                console.log("hello",res.data)
                SetUsers(res.data)
              })
            } catch (error) {
              console.error('Error fetching project data:', error);
            }
          };
          fetchProjectData(projectId);
    },[])

    useEffect(() => {
        console.log("hiih",users); // Check if the projects state is updated
      }, [users]);
    
      const [inputValue, setInputValue] = useState('');

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };

 async function handleButtonClick(e){
    e.preventDefault()

    await axios.post(`http://localhost:1337/userproject/api/adduser/${inputValue}`,{
      headers:{
        'x-access-token':localStorage.getItem('token')
      },
      project:{
         id:projectId,
         accesslevel:1
      }
    }).then((res)=>{
        alert("User added to this Project")
    }).catch((res)=>{
         alert("Check the Email Address")
    })
  }

    return(
    <>
    <h1>Welcome to the Page</h1>
          <ul>
     {users.map((user) => {
    console.log("ello",user)
    // console.log(user.id)
     return (<>
     <div>
      <button onClick={()=>handleClick(user.email,user.name)}>see view</button>
      <button onClick={()=>handlePlot(user.email,user.name)}>plot more</button>
      </div></>)
    //  return <li key={user.email} onClick={() => handleClick(user.email,user.name)}>{user.name}</li>;
  })} 
 </ul>
 <h1>ADD MORE USER</h1>
    <div>
      <input type="email" value={inputValue} onChange={handleInputChange} />
      <button onClick={handleButtonClick}>Submit</button>
    </div>
    </>
    )
}