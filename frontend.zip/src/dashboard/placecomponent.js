// import React, { useState,useEffect ,useRef} from 'react';
// import Chart from 'chart.js/auto';


// // const PlotComponent = ({ key, dataEntry, index, ShareGraph }) => {
// //   const [currentValue, setCurrentValue] = useState('');
// //   const chartRef = useRef(null);
// //   useEffect(() => {
// //     if (dataEntry) {
// //       renderChart();
// //     }
// //       return () => {
// //         if (chartRef.current) {
// //           chartRef.current.destroy();
// //         }
// //       };
    

// //   }, [dataEntry]);

// //   const renderChart = () => {
// //     const canvas = document.getElementById(`plot-${index}`);
// //     const ctx = canvas.getContext('2d');
// //     console.log(dataEntry);
  
// //     // Destroy previous chart if it exists
// //     if (chartRef.current) {
// //       chartRef.current.destroy();
// //     }
// //     if (ctx.chart) {
// //       ctx.chart.destroy();
// //     }
  
// //     const xLabels = dataEntry.map((dataPoint) => dataPoint.data.time);
// //     const values = dataEntry.map((dataPoint) => dataPoint.data.value);
// //    console.log(xLabels)
// //     const chartConfig = {
// //       type: 'line',
// //       data: {
// //         labels: xLabels,
// //         datasets: [
// //           {
// //             label: 'Plot Data',
// //             data: values,
// //             backgroundColor: 'rgba(0, 123, 255, 0.5)',
// //             borderColor: 'rgba(0, 123, 255, 1)',
// //             borderWidth: 1,
// //             fill: false,
// //           },
// //         ],
// //       },
// //       options: {
// //         responsive: true,
// //         maintainAspectRatio: false,
// //         scales: {
// //           x: {
// //             type: 'category', // Treat x-axis as regular values
// //             title: {
// //               display: true,
// //               text: 'Time',
// //             },
// //           },
// //           y: {
// //             title: {
// //               display: true,
// //               text: 'Value',
// //             },
// //           },
// //         },
// //       },
// //     };
  
// //     // Create a new chart
// //     // ctx.chart = new Chart(ctx, chartConfig);
// //     // setTimeout(() => {
// //     //   // Create a new chart
// //     //   ctx.chart = new Chart(ctx, chartConfig);
// //     // }, index * 100); // A
// //     // chartRef.current = new Chart(ctx, chartConfig);
// //     setTimeout(() => {
// //       // Create a new chart
// //       chartRef.current = new Chart(ctx, chartConfig);
// //     }, 0);
// //   };  

// //   const handleInputChange = (e) => {
// //     setCurrentValue(e.target.value);
// //   };

// //   const handleShareClick = (e) => {
// //     ShareGraph(e,dataEntry, currentValue);
// //   };

// //   return (
// //     <div key={key}>
// //       <canvas id={`plot-${index}`} width={400} height={200}></canvas>
// //       <input type="email" value={currentValue} onChange={handleInputChange} />
// //       <button onClick={(e)=>{handleShareClick(e)}}>Shared</button>
// //     </div>
// //   );
// // };

// // import React, { useState, useEffect, useRef } from 'react';
// // import Chart from 'chart.js/auto';

// const PlotComponent = ({ plotKey, dataEntry, index, ShareGraph }) => {
//   const [currentValue, setCurrentValue] = useState('');
//   const chartRef = useRef(null);

//   useEffect(() => {
//     if (dataEntry) {
//       renderChart();
//     }

//     return () => {
//       if (chartRef.current) {
//         chartRef.current.destroy();
//       }
//     };
//   }, [dataEntry]);

//   const renderChart = () => {
//     const canvas = document.getElementById(`plot-${index}`);
//     const ctx = canvas.getContext('2d');

//     if (chartRef.current) {
//       chartRef.current.destroy();
//     }

//     const xLabels = dataEntry.map((dataPoint) => dataPoint.data.time);
//     const values = dataEntry.map((dataPoint) => dataPoint.data.value);

//     const chartConfig = {
//       // Chart configuration
//       type: 'line',
//             data: {
//               labels: xLabels,
//               datasets: [
//                 {
//                   label: 'Plot Data',
//                   data: values,
//                   backgroundColor: 'rgba(0, 123, 255, 0.5)',
//                   borderColor: 'rgba(0, 123, 255, 1)',
//                   borderWidth: 1,
//                   fill: false,
//                 },
//               ],
//             },
//             options: {
//               responsive: true,
//               maintainAspectRatio: false,
//               scales: {
//                 x: {
//                   type: 'category', // Treat x-axis as regular values
//                   title: {
//                     display: true,
//                     text: 'Time',
//                   },
//                 },
//                 y: {
//                   title: {
//                     display: true,
//                     text: 'Value',
//                   },
//                 },
//               },
//             },
//     };

//     // setTimeout(() => {
//       // Create a new chart
//       chartRef.current = new Chart(ctx, chartConfig);
//     // }, 0);
//   };

//   const handleInputChange = (e) => {
//     setCurrentValue(e.target.value);
//   };

//   const handleShareClick = (e) => {
//     ShareGraph(e, dataEntry, currentValue);
//   };

//   return (
//     <div key={plotKey}>
//       <canvas id={`plot-${index}`} width={400} height={200}></canvas>
//       <input type="email" value={currentValue} onChange={handleInputChange} />
//       <button onClick={(e) => { handleShareClick(e) }}>Shared</button>
//     </div>
//   );
// };

// // export default PlotComponent;


// export default PlotComponent;

import React, { useState, useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';

const PlotComponent = ({ plotKey, dataEntry, index, ShareGraph }) => {
  const [currentValue, setCurrentValue] = useState('');
  const chartRef = useRef(null);
  useEffect(() => {
    if (dataEntry) {
      renderChart();
    }
  }, [dataEntry]);


  const renderChart = () => {
  const plotElement = document.getElementById(`plot-${index}`);
        // const data = dataEntry.content;
        console.log("hello mr manoj")
        // const xData = data.map(obj => obj.x);
        // const yData = data.map(obj => obj.y);
        const xData = dataEntry.map((dataPoint) => dataPoint.data.time);
        const yData = dataEntry.map((dataPoint) => dataPoint.data.value);
        console.log(xData,yData)
        // Check if a chart already exists on the canvas element
        if (plotElement.chart) {
          plotElement.chart.destroy();
        }
  
        const chart = new Chart(plotElement, {
            type: 'line',
                    data: {
                      labels: xData,
                      datasets: [{
                        label: 'Y Values',
                        data: yData,
                        borderColor: 'blue',
                        fill: false
                      }]
                    },
                    options: {
                      responsive: true,
                      scales: {
                        x: {
                          type: 'linear',
                          position: 'bottom',
                        //   max: 40, // Set the maximum value of the x-axis
                        //   min: 0,  // Set the minimum value of the x-axis
                        },
                      }
                    }
        });
        plotElement.chart = chart;
      };
  
        // Store the chart instance as a property of the canvas element
        

  const handleInputChange = (e) => {
    setCurrentValue(e.target.value);
  };

  const handleShareClick = (e) => {
    ShareGraph(e, dataEntry, currentValue);
  };

  return (
    <div key={plotKey}>
      <canvas id={`plot-${index}`} width={400} height={200}></canvas>
      <input type="email" value={currentValue} onChange={handleInputChange} />
      <button onClick={(e) => { handleShareClick(e) }}>Shared</button>
    </div>
  );
};

export default PlotComponent;

