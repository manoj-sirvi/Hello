import axios from "axios";
import React, { useState,useEffect } from "react";
// import ChartComponent from "./image";
// export default function Dashboard(){
//     const [image,setImage]=useState(null)
//     // let username="";
//     const [username, setUsername]=useState("")
    // useEffect(()=>{

    //     async function call(){
    //      await axios.post("http://localhost:1337/api/username",{
    //         headers:{
    //          'x-access-token': localStorage.getItem('token')
    //         }
    //     }).then(res=>{
    //         console.log("hii it is success")
    //         // username=res.name;
    //         console.log(res.data)
    //         setUsername(res.data.name)
    //     }).catch(error=>{
    //         console.log("user doesn't exist");
    //     })
    // }
    // call();
    // },[image])


//     async function GetData(event){
//         event.preventDefault();

//         const time={
//             t1:12,
//             t2:80
//         }
//        await axios.post("http://localhost:1337/dataset/mydata",time).then(res=>{
//            console.log("ok")
//         }).catch(error=>{
//             console.log(error);
//         })
//     }
//     return (
//      <>
//      {
//         // console.log("wekwkef");
//         console.log(username)
//      }
//      <h1>Hii my name is {username}</h1>
//      <button type="submit" onClick={GetData} >Plot</button>
//      <ChartComponent/>
     
//      </>
//     );
// }
import ProjectPage from "./projects";
export default function Dashboard(){

    const [username, setUsername]=useState("")

    // useEffect(()=>{

    //             async function call(){
    //              await axios.post("http://localhost:1337/api/username",{
    //                 headers:{
    //                  'x-access-token': localStorage.getItem('token')
    //                 }
    //             }).then(res=>{
    //                 console.log("hii it is success")
    //                 // username=res.name;
    //                 console.log(res.data)
    //                 setUsername(res.data.name)
    //             }).catch(error=>{
    //                 console.log("user doesn't exist");
    //             })
    //         }
    //         call();
    //     })
    return (
        <>
        <h1>Hii my name is Manoj</h1>
        <ProjectPage/>
        </>
    )
}