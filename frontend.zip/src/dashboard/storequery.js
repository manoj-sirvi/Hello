import React, { useState } from "react";
import { useSearchParams,useLocation  } from 'react-router-dom';
import PlotComponent from "./placecomponent";
import axios from "axios";
export default function SaveQuery(){
    const [starttime,setStarttime]=useState(0);
    const [endtime,setEndtime]=useState(0);
    const location = useLocation();
    const [searchParams] = useSearchParams(location.search);
    const projectId = searchParams.get('projectId');
    const [current,setCurrentalue]=useState([])

    // const 
    async function handleChnages(e){
        await axios.post("http://localhost:1337/userproject/api/project/plot",{
            headers:{
                'x-access-token':localStorage.getItem('token')
            },body:{
                projectId:projectId,
                input:{
                    start:starttime,
                    end:endtime
                }
            }
        }).then((res)=>{
            setCurrentalue([...current, res.data.data]);
        }).catch((err)=>{
            console.log("ERROR")
        })
    }
    async function ShareGraph(e,dataEntry,currentValue){
        e.preventDefault();
        await axios.post('http://localhost:1337/sharing/api/shared',{
             headers:{
              'x-access-token':localStorage.getItem('token')
             },
             body:{
               userid2:currentValue,
               projectId:projectId,
               data:dataEntry
             }
        }).then((res)=>{
           alert("successfully shared")
    
        }).catch((res)=>{
             alert("Error while sharing")
        })
      }
    return (
        <>
        <div>
        <input value={starttime} placeholder="start time" onChange={(e)=>{setStarttime(e.target.value)}}></input>
        <input value={endtime} placeholder="end time" onChange={(e)=>{setEndtime(e.target.value)}}></input>
        <button onClick={handleChnages}>Submit</button>
        </div>
        <div>
                 {current.map((dataEntry, index) => (
                    <PlotComponent
                      key={index}
                      dataEntry={dataEntry}
                      index={index}
                      ShareGraph={ShareGraph}
                    />
                  ))}
        </div>
        </>
    )
}