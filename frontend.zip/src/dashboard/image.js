import React, { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';
import axios  from 'axios';
const ChartComponent = () => {
  const chartRef = useRef(null);

  useEffect(() => {
    let chartInstance;

    const ctx = chartRef.current.getContext('2d');

    if (chartInstance) {
      chartInstance.destroy(); // Destroy the previous chart instance
    }

    chartInstance = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
        datasets: [
          {
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: [
              'rgba(255, 99, 132, 0.2)',
              'rgba(54, 162, 235, 0.2)',
              'rgba(255, 206, 86, 0.2)',
              'rgba(75, 192, 192, 0.2)',
              'rgba(153, 102, 255, 0.2)',
              'rgba(255, 159, 64, 0.2)',
            ],
            borderColor: [
              'rgba(255, 99, 132, 1)',
              'rgba(54, 162, 235, 1)',
              'rgba(255, 206, 86, 1)',
              'rgba(75, 192, 192, 1)',
              'rgba(153, 102, 255, 1)',
              'rgba(255, 159, 64, 1)',
            ],
            borderWidth: 1,
          },
        ],
      },
      options: {
        scales: {
          y: {
            beginAtZero: true,
          },
        },
      },
    });

    return () => {
      if (chartInstance) {
        chartInstance.destroy(); // Cleanup on unmount
      }
    };
  }, []);

  const saveChartImage = () => {
    const chartCanvas = chartRef.current;

    // Convert the chart canvas to a base64-encoded image
    const imageData = chartCanvas.toDataURL('image/png');

    // Send the image data to the server using Axios
    axios.post('http://localhost:1337/api/save-chart', { imageData })
      .then(response => {
        console.log('Chart image saved successfully!', response.data);
      })
      .catch(error => {
        console.error('Error saving chart image:', error);
      });
  };

  return (
    <div>
      <canvas ref={chartRef} />
      <button onClick={saveChartImage}>Save Chart Image</button>
    </div>
  );
};

export default ChartComponent;
