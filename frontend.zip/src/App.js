import logo from './logo.svg';
import './App.css';
import Login from './login/login.jsx'
import './login/login.css'
import Registration from './registration/registration';
import {BrowserRouter,Route, Routes} from 'react-router-dom';
// import Home from './home/home.js'
import Home from './home/home.js';
import Dashboard from  './dashboard/dashboard';
import React, { Component } from 'react';
import Layout from './layout/layout.js'
import Project from './dashboard/project';
import PlotPage from './dashboard/plots';
import Shared from './dashboard/shared';
import Handling from './dashboard/query';
import SaveQuery from './dashboard/storequery'
function App() {
  return (
   
    <div>
     
     <BrowserRouter>
     {/* <Layout/> */}
     <Routes> 
      {/* <Login/> */}
      <Route path="/" exact element={<Home/>}/> 
      <Route path="/login" exact element={<Login/>}/> 
       <Route path="/registration" exact element={<Registration/>}/>
       <Route path='/dashboard' exact element={<Dashboard/>}/>
       <Route path='/projects' exact element={<Project/>}/>
       <Route path='/users' exact element={<Handling/>}/>
       <Route path='/projects/shared' exact element={<Shared/>}/>
       <Route path='/users/plots' exact element={<SaveQuery/>}/>
      </Routes>
     </BrowserRouter>
    </div>
  );
}

export default App;
