import React, { Component } from 'react';
import './home.css'
export default function Home (){
        return (
            <div>
              <nav className="navbar">
  <ul className="nav-links">
    <li><a href="/">Home</a></li>
  </ul>
  <div className="auth-links">
    <a href="/registration" className="auth-link">Register</a>
    <a href="/login" className="auth-link">Login</a>
  </div>
</nav>
            </div>
        );
    
};