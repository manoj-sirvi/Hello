const express=require('express')
const cors = require('cors')
const mongoose = require('mongoose');
const users=require("./routers/registration");
const projects=require('./routers/projects')
const userprojects=require('./routers/userproject')
const shared=require('./routers/shared')
// const datasets=require("./routers/data")
const bodyParser = require('body-parser');
const app=express()
app.use(cors())
app.use(bodyParser.json());
app.get('/', (req, res) => {
    res.send('GET request to the homepage')
  })



const url="mongodb://localhost:27017/test"
mongoose
  .connect(url, { useNewUrlParser: true })
  .then(() => console.log(`Database connected successfully`))
  .catch((err) => console.log(err));
  mongoose.Promise = global.Promise;
var PORT = 1337;


app.use("/user",users);
app.use('/project',projects)
app.use('/userproject',userprojects)
app.use('/sharing',shared)

const Chart = mongoose.model('Chart', new mongoose.Schema({
  images: [{ type: String }]
}));

app.listen(PORT, function(err){
     if (err) console.log(err);
     console.log("Server listening on PORT", PORT);
  });

