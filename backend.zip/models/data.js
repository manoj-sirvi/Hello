const mongoose=require('mongoose')

const Schema = mongoose.Schema;

const Data=new Schema({
    time:{
       type:Number,
    },
    value:{
        type:Number
    }
});

const data=mongoose.model('data',Data);

module.exports=data;