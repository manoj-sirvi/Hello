const mongoose=require('mongoose')

const schema=mongoose.Schema;

const UserProject=new schema({
    userid:{
        type:String,
        required:true
    },
    projectid:{
        type:String,
        required:true,
    },
    accesslevel:{
       type:Number,
       default:0
    }
    ,
    queries:[{
        starttime:{
            type:Number
        },
        endtime:{
            type:Number
        }
}]
})

const db=mongoose.connection.useDb('test')
const userproject=db.model('userprojects',UserProject);

module.exports=userproject;