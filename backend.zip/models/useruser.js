const mongoose=require('mongoose')

const schema=mongoose.Schema;

const Useruser=new schema({
    sharedby:{
        type:String,
        required:true,
    }
    ,
    sharedto:{
        type: String,
        required:true,
    }
    ,
    projectid:{
       type:String,
       required:true, 
    }
    , data:{
        type:schema.Types.Mixed,
    }
})

const db=mongoose.connection.useDb('test')

const useruser=db.model('shared',Useruser)

module.exports=useruser;