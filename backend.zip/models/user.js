const mongoose = require('mongoose');
// validator = require('express-validator');
const Schema = mongoose.Schema;
const Project = require('./projects');
const User=new Schema({
    name:{
        type:String,
        require:true
    },
    email:{
        type:String,
        required:true,
    },
    password:{
        type:String,
        required:true
    }
    ,
    // projects: [{
    //     projectId: { type: Schema.Types.Mixed, ref: 'Project' },
    //     accessLevel: { type: String, enum: ['read', 'write', 'admin'] },
    //     data:[{
    //         id:{
    //             type:String
    //         },
    //         content:{
    //           type: Schema.Types.Mixed,
    //         }
    //     }]
    //   }]
});

const db=mongoose.connection.useDb('Information')

const user=db.model('user',User);

module.exports=user;