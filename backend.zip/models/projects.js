const mongoose=require('mongoose');
// const { schema } = require('./user');

const Schema = mongoose.Schema;

const Project=new Schema({
    name:{
        type:String,
        required:true,
    },
    id:{
        type:String,
        required:true,
    },
    creator:{
       type:String,
       required:true
    },
    description:{
        type:String,
        required:true
    },
    data:[{
        time:{
            type:Number,
        },
        value:{
            type:Number
        }
    }]
});

const db=mongoose.connection.useDb('test')

const project=db.model('projects',Project);

module.exports=project;