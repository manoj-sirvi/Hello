const fs = require('fs');
const mongoose = require('mongoose');

// Define the schema for your data
// const DataModel = require("./../models/data")
const user=require("./../models/userproject");
const Project = require('../models/projects');
const userproject = require('./../models/userproject');
// Create a model based on the schema
// const DataModel = mongoose.model('Data', dataSchema);
const url="mongodb://localhost:27017/test"

function generateDataPoints(range) {
  const dataPoints = [];
  for (let i = 0; i < 40000; i++) {
    const x = i/1000; // Replace with your x-axis data generation logic
    const y = (Math.random() * range); // Replace with your y-axis data generation logic
    dataPoints.push({ time:x, value:y });
  }
  return dataPoints;
}

// Connect to your MongoDB database
mongoose.connect(url, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(async () => {
    console.log('Connected to MongoDB');

    // Read the JSON file
    // fs.readFile('./../sample.json', 'utf8', (error, data) => {
    //   if (error) {
    //     console.error('Error reading the file:', error);
    //     return;
    //   }

      // Parse the JSON data
      try {
        newData=generateDataPoints(400);
        const data={
           starttime:3,
           endtime:8
        }
        // console.log(newData)
        // const updatedproject = await Project.findOneAndUpdate(
        //   { id:'8d2af083d994394731e40fa110282ccc'},
        //   { $push: { 'data': newData } },
        //   { new: true }
        // );
        const neccassarydata=await Project.aggregate([
          { $unwind: '$data' }, // Unwind the data array
          { $match: { 'data.time': { $gte: 6, $lte: 9 } } } // Match the range condition
          ,{
            $project: {
              _id: 0, // Exclude the _id field
              'data.time': 1,
              'data.value': 1
            }
          }])
        // console.log()
        // console.log(updatedproject[0].data)
        console.log(neccassarydata)
      
        if (!neccassarydata) {
          
          console.log('User not found or project ID not matched');
          return;
        }
      
          console.log('Porject updated successfully:');
        }
       catch (parseError)
        {
        console.error('Error parsing the JSON:', parseError);
       }
    })
  .catch(error => {
    console.error('Error connecting to MongoDB:', error);
  });

