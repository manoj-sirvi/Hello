const useruser=require('./../models/useruser')
const express=require('express')
const router=express.Router();
const jwt = require('jsonwebtoken')
const bcrypt = require('bcryptjs')

router.get('/api/getshareditems',async(req,res)=>{
    const token=req.headers['x-access-token'];
    const decoding=jwt.verify(token,'secret123')
    console.log(decoding.email)
    try{
        const dataList=await useruser.find({
             sharedto:decoding.email,
        }).select('data -_id')
        // console.log(dataList[0].data)
        // return dataList.data;
        res.json(dataList)
    }
    catch(error){
        res.send("error while Preprocessing")
    }
})

router.post('/api/shared',async(req,res)=>{
    // try{
        const token=req.body.headers['x-access-token'];
        const decoding=jwt.verify(token,'secret123')
        console.log(req.body)
        const information={
            sharedby:decoding.email,
            sharedto:req.body.body.userid2,
            projectid:req.body.body.projectId,
            data:req.body.body.data['content']
        }
        console.log(information)

        await useruser.create(
            information
        )
        res.json({status:'ok'})
    // }
    // catch(err){
    //     res.json({status:'error'})
    // }
})

module.exports=router;