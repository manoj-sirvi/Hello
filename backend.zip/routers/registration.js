const { default: mongoose } = require("mongoose");
const user=require("./../models/user")
const express=require('express')
const router=express.Router();
const jwt = require('jsonwebtoken')
const bcrypt = require('bcryptjs')
router.post('/api/registration',async (req,res)=>{
    console.log(req.body)
    try{
        const newPassword = await bcrypt.hash(req.body.password, 10)
        await user.create({
			name: req.body.name,
			email: req.body.email,
			password:newPassword,
            // projects:[],
		})
		res.json({ status: 'ok' })
	} catch (err) {
		res.json({ status: 'error', error: 'Duplicate email' })
	}
    
})

router.post('/api/login',async (req,res)=>{
  console.log(req.body)
   const current =await user.findOne({
       email:req.body.email,
   })
   console.log(current)
   if(!current){
        res.json({status:'error',
        error:"invalid login"})
    }

    else{
        const isPasswordValid = await bcrypt.compare(
            req.body.password,// new password
            current.password // hashing wala 
        )
        if (isPasswordValid) {
            console.log(user.name,user.email)
            const token = jwt.sign(
                {
                    name: current.name,
                    email: current.email,
                },
                'secret123'
            )
            res.json({status:'ok',user:token})
        }
        else{
            res.json({status:'ok',user:false})
        }

    
        
    }
})

// router.post('/api/username',async (req,res)=>{
//    console.log(req)
//    const token=req.body.headers['x-access-token']
//    console.log(token)
//    try{
//     const decode=jwt.verify(token,'secret123')
//     console.log(decode)
//     const email=decode.email;
//     console.log(email)
//     const current =await user.findOne({
//         email:email,
//     })
//     return res.json({status:'ok',name:current.name})
//    } 
//    catch(err){
//     res.json({status:'error',error:'token error'})
//    } 
// })

module.exports=router;