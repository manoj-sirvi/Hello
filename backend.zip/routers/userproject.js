const { default: mongoose } = require("mongoose");
const user=require("./../models/user")
const express=require('express')
const router=express.Router();
const jwt = require('jsonwebtoken')
const bcrypt = require('bcryptjs')
const userproject=require('./../models/userproject')
const Project = require('./../models/projects'); 
const crypto = require('crypto');
const project = require("./../models/projects");

const generateProjectId = (userId) => {
    const timestamp = Date.now().toString(); // Get the current timestamp
    const userData = userId.toString(); // Convert the user ID to string
  
    const hash = crypto.createHash('md5'); // Create a hash object
    hash.update(userData + timestamp); // Update the hash with user data and timestamp
  
    return hash.digest('hex'); // Generate the hexadecimal representation of the hash
  };
router.post("/api/createproject",async (req,res)=>{
    const token=req.body.headers['x-access-token']
    console.log(req.body)
    console.log("hiiiiwfihw")
 //    res.json({status:'ok'})
//    try{
        const decoding=jwt.verify(token,'secret123')
        const id=generateProjectId(decoding.email)
        console.log("helloo")
        const project={
         id:id,
         name:req.body.project.name,
         creator:decoding.name,
         description:req.body.project.description,
         data:[]
         // roles[decoding.email]:
        }
        console.log(project)
        await Project.create(
           project
        )
     //    console.log("yes")

        try{
        // await user.updateOne({email:decoding.email},{$push:{projects:{projectId:id,accessLevel:'admin',data:[]}}})
        await userproject.create({
            userid:decoding.email,
            projectid:id,
            accesslevel:0,
            queries:[]
        })
        }
        catch{
        }
        res.json({status:'ok',project:project});
    //  } 
    //  catch{
    //      res.json({status:'error'});
    //  }
    
 })
 

 router.get('/api/projects/:projectId', async (req, res) => {
    const projectId = req.params.projectId;
    const accessLevel=req.headers['accesslevel'];
    const token=req.headers['x-access-token']
    const decoding=jwt.verify(token,'secret123')
    console.log(decoding)
    const id=(decoding.email)
    console.log(id,accessLevel)

    console.log(projectId)
    try {
        // Find users with the given project ID in their projects array
        const users = await userproject.find({projectid:projectId, $or: [
            { userid: id },
            { accesslevel: { $gt: 1 } }]}).select('userid -_id').exec();
        const userid=users.map(obj=>obj.userid)
        const usersinfo = await user.find({ email: { $in: userid } }).select('name email -_id');;
        // return users;  
        console.log(usersinfo)
        // console.log(users)
        res.json(usersinfo)
        
      } catch (error) {
        console.error('Error fetching users:', error);
        res.json("sendind");
      }
   
  });


  router.get("/api/username/data/:userId",async (req,res)=>{
    const userId = req.params.userId;
    const projectId=req.headers.id;
    console.log(req)
    // const accessLevel=req.headers.accessLevel;
    // const decoding=jwt.verify(req.headers.token,'secret123')
    console.log(userId,projectId)
    const current = await userproject.findOne({
        userid: userId,
        projectid:projectId,
      }).exec();

      console.log(current)
  
      // Extract the data list from the user document
      const dataList = current ? current.data : [];
    //   console.log(typeof dataList)
    //   console.log("STarting")
      console.log(dataList)
      res.send(dataList);

})

router.post('/api/adduser/:userid',async(req,res)=>{

    const Entry={
        userid:req.params.userid,
        projectid:req.body.project.id,
        accesslevel:req.body.project.accesslevel,
        data:[]
    };
    const currentuser=await user.findOne({
        email:req.params.userid
    });
    if(!currentuser){
        res.json({status:'error'})
    }
try{
    await userproject.create(
        Entry
    )
    res.json({status:'ok'})
}catch(error){
    res.json({status:'error'})
}
})

router.post("/api/plotting",async (req,res)=>{
    console.log("Hiiii")
    const start=req.body.body.query.starttime;
    const end=req.body.body.query.endtime;
    const token=req.body.headers['x-access-token']
    // console.log(req.body)
    // console.log("hiiiiwfihw")
    const decoding=jwt.verify(token,'secret123')
    const neccassarydata=await Project.aggregate([
        { $unwind: '$data' }, // Unwind the data array
        { $match: { 'data.time': { $gte: start, $lte: end } } } // Match the range condition
        ,{
          $project: {
            _id: 0, // Exclude the _id field
            'data.time': 1,
            'data.value': 1
          }
        }])
        // const up=userproject.findOneAndUpdate({
        //     userid:decoding.email,projectid:req.body.body.projectid
        // },{
        //     '$push':{
        //         'queries':{
        //             startime:startime,
        //             endtime:endtime
        //         }
        //     }
        // })
        // console.log(neccassarydata)
        console.log("calles")
        res.json({data:neccassarydata})
})

router.get("/api/plot",async (req,res)=>{

    // console.log("entry")
    const token=req.headers['x-access-token']
    const decoding=jwt.verify(token,'secret123')

    const userid=decoding.email;
    const projectid=req.headers['projectid'];
    // console.log(req.headers)
    // console.log(userid,projectid)
    // const projectid=req.b
    const User=await userproject.findOne({
       userid:userid,projectid:projectid
    })
    // console.log(User)
    if(User){
    const queries=User.queries;
    console.log(queries)
    res.json({'queries':queries});
    }
    else{
        res.json({'queries':[]})
    }

})

router.post("/api/project/plot",async (req,res)=>{
    console.log("Hiiii")
    const start=req.body.body.input.start;
    const end=req.body.body.input.end;
    const token=req.body.headers['x-access-token']
    // console.log(req.body)
    // console.log("hiiiiwfihw")
    console.log(start,end,token)
    const decoding=jwt.verify(token,'secret123')
    const neccassarydata=await Project.aggregate([
        // { $match: { id:req.body.body.projectId } },
        { $unwind: '$data' }, // Unwind the data array
        { $match: { 'data.time': { $gte: Number(start), $lte: Number(end) } } } // Match the range condition
        ,{
          $project: {
            _id: 0, // Exclude the _id field
            'data.time': 1,
            'data.value': 1
          }
        }])
        console.log("end")
        console.log(req.body.body.projectId,decoding.email)
        const up=await userproject.findOneAndUpdate({
            userid:decoding.email,projectid:req.body.body.projectId
        },{
            '$push':{
                'queries':{
                    starttime:start,
                    endtime:end
                }
            }
        })
        console.log("yes")
        // console.log(up)
        // console.log(neccassarydata)
        // console.log("calling")
        res.json({data:neccassarydata})
})
module.exports=router;