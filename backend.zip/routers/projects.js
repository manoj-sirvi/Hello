const { default: mongoose } = require("mongoose");
const user=require("./../models/user")
const express=require('express')
const router=express.Router();
const jwt = require('jsonwebtoken')
const bcrypt = require('bcryptjs')
const userproject=require('./../models/userproject')
const Project = require('./../models/projects'); 

router.get('/api/projects',async(req,res)=>{
    // console.log("enter")
    console.log(req.headers)
    // try {
        const token=req.headers['x-access-token']
        const decoding=jwt.verify(token,'secret123')
        console.log(decoding)
        const projectIdsjson =await userproject.find({
            userid:decoding.email,
        }).select('projectid acesslevel -_id')
        // console.log(current)
        const projectIds = projectIdsjson.map(obj => obj.projectid);
        // const projectIds = current.projects.map(project => project.projectId); // Retrieve all project IDs for the user
        console.log(projectIds)
        // const projects = await Project.find({ id: { $in: projectIds } }).select('id description creator').populate({
        //   path: 'id',
        //   select: 'accesslevel'
        // }).exec()

        const projects = await Project.find({ id: { $in: projectIds } }).select('id description creator').exec();

    const populatedProjects = await Promise.all(
      projects.map(async (project) => {
        const userProject = await userproject.findOne({ projectid: project.id,userid:decoding.email });
        const accesslevel = userProject ? userProject.accesslevel : null;
        return {
          ...project._doc,
          accesslevel
        };
      })
    );
        console.log(populatedProjects)
        res.json(populatedProjects)
      // } catch (error) {
      //   console.error('Error fetching user projects:', error);
      //   res.status(500).json({ error: 'Internal Server Error' });
      // }
})

module.exports=router;
