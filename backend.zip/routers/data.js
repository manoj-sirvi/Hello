const { default: mongoose } = require("mongoose");
const data=require("./../models/data")
const express=require('express')
const router=express.Router();
const user=require('./../models/user')
const Project = require('./../models/projects'); 
const jwt = require('jsonwebtoken')
const bcrypt = require('bcryptjs')
router.post("/mydata",(req,res)=>{
    var t1=req.body.t1;
    var t2=req.body.t2;
    data.find({time:{
        $gte:t1,$lte:t2
    }}).then(data=>{
        console.log(data)
        return res.json({status:'ok'})
       
    }).catch(error=>{
        console.log("Error:", error);
        return res.json({status:'error'})
      
    })
    
})


// router.get('/api/projects', (req, res) => {
//     res.send('GET request to the homepage')
//   })
// router.get('/api/projects',async(req,res)=>{
//     // console.log("enter")
//     // console.log(req.headers)
//     try {
//         const token=req.headers['x-access-token']
//         const decoding=jwt.verify(token,'secret123')
//         // console.log(decoding)
//         const current =await user.findOne({
//             email:decoding.email,
//         })
//         // console.log(current)
//         const projectIds = current.projects.map(project => project.projectId); // Retrieve all project IDs for the user
//         // console.log(projectIds)
//         const projects = await Project.find({ id: { $in: projectIds } }).select('id description creator');;
//         // console.log(projects)
//         res.json(projects)
//       } catch (error) {
//         console.error('Error fetching user projects:', error);
//         res.status(500).json({ error: 'Internal Server Error' });
//       }
// })




// // const generateProjectId = (userId) => {
// //     const timestamp = Date.now().toString(); // Get the current timestamp
// //     const userData = userId.toString(); // Convert the user ID to string
  
// //     const hash = crypto.createHash('md5'); // Create a hash object
// //     hash.update(userData + timestamp); // Update the hash with user data and timestamp
  
// //     return hash.digest('hex'); // Generate the hexadecimal representation of the hash
// //   };

// router.post("/api/createproject",async (req,res)=>{
//    const token=req.body.headers['x-access-token']
//    console.log(req.body)
//    console.log("hiiiiwfihw")
// //    res.json({status:'ok'})
//   try{
//        const decoding=jwt.verify(token,'secret123')
//        const id="123444"
//        console.log("helloo")
//        const project={
//         id:id,
//         name:req.body.project.name,
//         creator:decoding.name,
//         description:req.body.project.description,
//         // roles[decoding.email]:
//        }
//        console.log(project)
//        await Project.create(
//           project
//        )
//     //    console.log("yes")
//        try{
//        await user.updateOne({email:decoding.email},{$push:{projects:{projectId:id,accessLevel:'admin',data:[]}}})
//        }
//        catch{
//         // console.log("error while updating")
//        }
//        res.json({status:'ok'});
//     } catch{
//         res.json({status:'error'});
//     }
   
// })


// router.get('/api/projects/:projectId', async (req, res) => {
//     const projectId = req.params.projectId;
//     console.log(projectId)
  
//     // Perform necessary operations to fetch project data based on the project ID
//     // For example, query the database or access the data from another source
  
//     // Assuming you have fetched the project data, send it as the response
//     try {
//         // Find users with the given project ID in their projects array
//         const users = await user.find({ 'projects.projectId':projectId}).select('email name projects.accessLevel').exec();
//         // return users;  
//         console.log(users)
//         res.json(users)
        
//       } catch (error) {
//         console.error('Error fetching users:', error);
//         throw error;
//       }
   
//   });

// router.get("/api/username/data/:userId",async (req,res)=>{
//         const userId = req.params.userId;
//         const projectId=req.headers.id;
//         console.log(req)
//         // const accessLevel=req.headers.accessLevel;
//         // const decoding=jwt.verify(req.headers.token,'secret123')
//         console.log(userId,projectId)
//         const current = await user.findOne({
//             email: userId,
//             'projects.projectId': projectId,
//             // accessLevel: { $lt: accessLevel }
//           }).exec();

//           console.log(current)
      
//           // Extract the data list from the user document
//           const dataList = current ? current.projects.find(project => project.projectId === projectId)?.data : [];
//         //   console.log(typeof dataList)
//           console.log("STarting")
//           console.log(dataList)
//           res.send(dataList);

// })

module.exports=router;